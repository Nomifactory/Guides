Extract inside your minecraft instance folder, overwriting existing files.

In your launcher, make sure to disable the pack version of GTCE / Shadows of Greg and enable the latest fixed versions from this zip.
